import requests
import json

url = "http://127.0.0.1:8000/api/v1/chat"
headers = {"Content-Type": "application/json"}

# Queries in different languages
queries = [
    {"q": "Fees kitni hai?", "expected": "Hindi"},
    {"q": "Admission process su che?", "expected": "Gujarati"},
    {"q": "Tell me about the campus.", "expected": "English"}
]

for item in queries:
    print(f"\n--- Testing: '{item['q']}' ---")
    data = {"query": item['q']}
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        res_json = response.json()
        print(f"Response: {res_json.get('response')[:100]}...") # Print first 100 chars
        print(f"Detected Language Tag: {res_json.get('detected_language')}")
    except Exception as e:
        print(f"Error: {e}")
